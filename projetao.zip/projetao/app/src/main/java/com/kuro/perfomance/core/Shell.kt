package com.kuro.performance.core

import java.io.DataOutputStream

object Shell {
    data class Result(val code: Int, val output: String)

    fun isRooted(): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        p.waitFor() == 0
    } catch (_: Exception) { false }

    fun exec(cmd: String, root: Boolean = false): Result = try {
        val proc = if (root) {
            Runtime.getRuntime().exec("su").also { p ->
                DataOutputStream(p.outputStream).use { it.writeBytes("$cmd\nexit\n") }
            }
        } else {
            Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        }
        val out = proc.inputStream.bufferedReader().readText() +
                  proc.errorStream.bufferedReader().readText()
        val code = proc.waitFor()
        Result(code, out.trim())
    } catch (e: Exception) {
        Result(-1, e.message ?: "exec failed")
    }

    fun readSys(path: String): String = try {
        java.io.File(path).readText().trim()
    } catch (_: Exception) { "N/A" }
}