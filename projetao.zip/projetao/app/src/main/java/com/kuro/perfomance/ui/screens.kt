package com.kuro.performance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kuro.performance.core.Shell
import com.kuro.performance.core.Tuner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen() {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val root = remember { Shell.isRooted() }

    var hw by remember { mutableStateOf("carregando...") }
    var cpu by remember { mutableStateOf("...") }
    var temp by remember { mutableStateOf("...") }
    var ram by remember { mutableStateOf("...") }
    var log by remember { mutableStateOf("") }

    fun refresh() = scope.launch(Dispatchers.IO) {
        hw = Tuner.hardwareSummary()
        cpu = Tuner.cpuInfo()
        temp = Tuner.thermalStatus()
        ram = Tuner.ramInfo(ctx)
    }

    LaunchedEffect(Unit) { refresh() }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(KuroBlack).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("KURO", fontSize = 36.sp, fontWeight = FontWeight.Black, color = KuroWhite)
            Text(
                "crDroid EDITION // ${if (root) "ROOT MODE" else "USER MODE"}",
                fontSize = 12.sp, color = KuroRed, letterSpacing = 3.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
        }

        item {
            KuroCard {
                SectionTitle("SISTEMA")
                Text(hw, color = KuroWhite, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }

        item {
            KuroCard {
                SectionTitle("STATUS")
                StatRow("CPU", cpu)
                StatRow("TERMICA", temp)
                StatRow("RAM", ram)
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = { refresh() }) {
                    Text("ATUALIZAR", color = KuroRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            KuroCard {
                SectionTitle("MODO DE DESEMPENHO")
                KuroButton("PERFORMANCE MAXIMO") {
                    scope.launch(Dispatchers.IO) { log = Tuner.applyPerformance(root); refresh().join() }
                }
                Spacer(Modifier.height(8.dp))
                KuroButton("BALANCEADO") {
                    scope.launch(Dispatchers.IO) { log = Tuner.applyBalanced(root); refresh().join() }
                }
                Spacer(Modifier.height(8.dp))
                KuroButton("BATERIA") {
                    scope.launch(Dispatchers.IO) { log = Tuner.applyBattery(root); refresh().join() }
                }
            }
        }

        item {
            KuroCard {
                SectionTitle("EMERGENCIA")
                Text("Reverte tudo pro padrao. Use se o device aquecer ou travar.",
                     color = KuroWhite.copy(alpha = 0.6f), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { scope.launch(Dispatchers.IO) { log = Tuner.restoreDefault(root); refresh().join() } },
                    colors = ButtonDefaults.buttonColors(containerColor = KuroRedDark),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text("RESTAURAR PADRAO", color = KuroWhite, fontWeight = FontWeight.Black) }
            }
        }

        item {
            KuroCard {
                SectionTitle("LIMPEZA")
                KuroButton("LIMPAR RAM") {
                    scope.launch(Dispatchers.IO) { log = Tuner.cleanRam(root); refresh().join() }
                }
                Spacer(Modifier.height(8.dp))
                KuroButton("MATAR BACKGROUND") {
                    scope.launch(Dispatchers.IO) { log = Tuner.killBackground() }
                }
            }
        }

        if (root) {
            item {
                KuroCard {
                    val oc = remember { Tuner.isOverclockable() }
                    SectionTitle("OVERCLOCK")
                    Text(
                        if (oc) "Kernel expoe frequencias acima do stock. Suporte OK."
                        else "Kernel atual nao expoe OC. Precisa kernel custom.",
                        color = if (oc) KuroAccent else KuroWhite.copy(alpha = 0.6f),
                        fontSize = 11.sp
                    )
                }
            }
            item { SystemAppsSection() }
        }

        if (log.isNotEmpty()) {
            item {
                KuroCard {
                    SectionTitle("LOG")
                    Text(log, color = KuroAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun SystemAppsSection() {
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<Tuner.SysApp>>(emptyList()) }
    var log by remember { mutableStateOf("") }
    val root = remember { Shell.isRooted() }

    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { apps = Tuner.listSystemApps(root) } }

    KuroCard {
        SectionTitle("APPS DO SISTEMA (${apps.size})")
        Text("Criticos da ROM ja filtrados. Testa um por um.",
             color = KuroWhite.copy(alpha = 0.6f), fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        apps.take(40).forEach { app ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    .background(KuroBlackSoft).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(app.name, color = KuroWhite, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { scope.launch(Dispatchers.IO) { log = Tuner.disableApp(app.pkg, root) } }) {
                    Text("OFF", color = KuroRed, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
                TextButton(onClick = { scope.launch(Dispatchers.IO) { log = Tuner.enableApp(app.pkg, root) } }) {
                    Text("ON", color = KuroAccent, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
            }
        }
        if (log.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(log, color = KuroAccent, fontSize = 11.sp) }
    }
}