package com.kuro.performance.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val KuroRed = Color(0xFFD10F0F)
val KuroRedDark = Color(0xFF7A0505)
val KuroBlack = Color(0xFF000000)
val KuroBlackSoft = Color(0xFF141414)
val KuroGray = Color(0xFF2A2A2A)
val KuroWhite = Color(0xFFF5F5F5)
val KuroAccent = Color(0xFFFF3B3B)

private val KuroColors = darkColorScheme(
    primary = KuroRed,
    onPrimary = KuroWhite,
    primaryContainer = KuroRedDark,
    secondary = KuroAccent,
    background = KuroBlack,
    onBackground = KuroWhite,
    surface = KuroBlackSoft,
    onSurface = KuroWhite,
    surfaceVariant = KuroGray,
    outline = KuroRed
)

@Composable
fun KuroTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = KuroColors, content = content)
}