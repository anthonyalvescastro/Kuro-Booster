package com.kuro.performance.core

import android.content.Context
import android.os.Build
import java.io.File

object Tuner {

    data class RomInfo(val name: String, val version: String, val kernel: String, val isCustom: Boolean)

    fun detectRom(): RomInfo {
        val crDroidVer = Shell.exec("getprop ro.crdroid.version").output
        val lineageVer = Shell.exec("getprop ro.lineage.version").output
        val kernel = System.getProperty("os.version") ?: "?"
        return when {
            crDroidVer.isNotBlank() -> RomInfo("crDroid", crDroidVer, kernel, true)
            lineageVer.isNotBlank() -> RomInfo("LineageOS", lineageVer, kernel, true)
            else -> RomInfo("AOSP/Custom", Build.DISPLAY, kernel, true)
        }
    }

    data class ThermalZone(val index: Int, val type: String, val temp: Double, val isCpu: Boolean)

    fun listThermalZones(): List<ThermalZone> {
        val zones = mutableListOf<ThermalZone>()
        for (i in 0..30) {
            val typeFile = File("/sys/class/thermal/thermal_zone$i/type")
            val tempFile = File("/sys/class/thermal/thermal_zone$i/temp")
            if (!typeFile.exists() || !tempFile.exists()) continue
            val type = try { typeFile.readText().trim() } catch (_: Exception) { continue }
            val temp = try { tempFile.readText().trim().toLong() / 1000.0 } catch (_: Exception) { 0.0 }
            val isCpu = type.contains("cpu", true) || type.contains("soc", true) ||
                        type.contains("tsens", true) || type.contains("apc", true) ||
                        type.contains("little", true) || type.contains("big", true) ||
                        type.contains("cluster", true) || type.contains("gpu", true)
            zones.add(ThermalZone(i, type, temp, isCpu))
        }
        return zones
    }

    enum class GpuType { ADRENO, MALI, UNKNOWN }

    fun detectGpu(): Pair<GpuType, String> = when {
        File("/sys/class/kgsl/kgsl-3d0").exists() ->
            GpuType.ADRENO to Shell.readSys("/sys/class/kgsl/kgsl-3d0/gpu_model")
        File("/sys/kernel/gpu").exists() || File("/proc/mali").exists() ||
            File("/sys/class/misc/mali0").exists() ->
            GpuType.MALI to Shell.readSys("/proc/mali/version").ifEmpty { "Mali" }
        File("/sys/devices/platform/ged").exists() ->
            GpuType.MALI to "Mali-G (MediaTek)"
        else -> GpuType.UNKNOWN to Build.HARDWARE
    }

    fun availableGovernors(): List<String> =
        Shell.readSys("/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")
            .split(" ").filter { it.isNotBlank() }

    fun cpuInfo(): String {
        val cores = Runtime.getRuntime().availableProcessors()
        val gov = Shell.readSys("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
        val freqs = Shell.readSys("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
        val freqMhz = freqs.toLongOrNull()?.div(1000) ?: 0
        return "cpu0: $gov @ ${freqMhz}MHz ($cores cores)"
    }

    private fun bestPerformanceGovernor(): String {
        val avail = availableGovernors()
        return when {
            "performance" in avail -> "performance"
            "schedutil" in avail -> "schedutil"
            "interactive" in avail -> "interactive"
            else -> avail.firstOrNull() ?: "schedutil"
        }
    }

    private fun bestBalancedGovernor(): String {
        val avail = availableGovernors()
        return when {
            "schedutil" in avail -> "schedutil"
            "interactive" in avail -> "interactive"
            "ondemand" in avail -> "ondemand"
            else -> avail.firstOrNull() ?: "schedutil"
        }
    }

    private fun bestBatteryGovernor(): String {
        val avail = availableGovernors()
        return when {
            "powersave" in avail -> "powersave"
            "conservative" in avail -> "conservative"
            "schedutil" in avail -> "schedutil"
            else -> avail.firstOrNull() ?: "powersave"
        }
    }

    fun applyPerformance(root: Boolean): String {
        if (!root) return "modo completo exige root (Magisk/KernelSU)."
        val sb = StringBuilder()
        val gov = bestPerformanceGovernor()
        val gpu = detectGpu()

        sb.appendLine(runCmd("for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $gov > \$c; done", "cpu governor -> $gov"))

        when (gpu.first) {
            GpuType.ADRENO -> {
                sb.appendLine(runCmd("echo 1 > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null", "adreno force clock"))
                sb.appendLine(runCmd("echo 1 > /sys/class/kgsl/kgsl-3d0/force_rail_on 2>/dev/null", "adreno force rail"))
                sb.appendLine(runCmd("echo 1 > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null", "adreno force bus"))
            }
            GpuType.MALI -> {
                sb.appendLine(runCmd("echo performance > /sys/class/misc/mali0/device/devfreq/*/governor 2>/dev/null", "mali governor"))
                sb.appendLine(runCmd("echo 0 > /sys/devices/platform/ged/hint_mode 2>/dev/null", "ged hint_mode off"))
            }
            else -> sb.appendLine("gpu desconhecida -- pulado")
        }

        val cpuZones = listThermalZones().filter { it.isCpu }
        if (cpuZones.isNotEmpty()) {
            for (z in cpuZones.take(3)) {
                sb.appendLine(runCmd("echo disabled > /sys/class/thermal/thermal_zone${z.index}/mode 2>/dev/null", "thermal ${z.index} (${z.type}) disabled"))
            }
        } else sb.appendLine("nenhuma zona thermal CPU detectada -- pulado")

        sb.appendLine(runCmd("echo 0 > /proc/sys/kernel/sched_rt_runtime_us 2>/dev/null", "sched_rt off"))
        sb.appendLine(runCmd("echo 950000 > /proc/sys/kernel/sched_rt_period_us 2>/dev/null", "sched_rt period"))
        sb.appendLine(runCmd("echo 100 > /proc/sys/vm/swappiness 2>/dev/null", "swappiness"))
        sb.appendLine(runCmd("echo 50 > /proc/sys/vm/vfs_cache_pressure 2>/dev/null", "vfs cache"))
        sb.appendLine(runCmd("for f in /sys/block/sd*/queue/scheduler /sys/block/mmcblk*/queue/scheduler; do echo none > \$f 2>/dev/null; done", "io scheduler -> none"))
        sb.appendLine(runCmd("echo 4096 > /sys/block/sd*/queue/read_ahead_kb 2>/dev/null", "read_ahead 4MB"))
        sb.appendLine(runCmd("echo 2048 > /proc/sys/kernel/random/read_wakeup_threshold 2>/dev/null", "entropy"))
        return sb.toString()
    }

    fun applyBalanced(root: Boolean): String {
        if (!root) return "modo balanceado exige root."
        val gov = bestBalancedGovernor()
        val sb = StringBuilder()
        sb.appendLine(runCmd("for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $gov > \$c; done", "cpu governor -> $gov"))
        for (z in listThermalZones().filter { it.isCpu }.take(3)) {
            sb.appendLine(runCmd("echo enabled > /sys/class/thermal/thermal_zone${z.index}/mode 2>/dev/null", "thermal ${z.index} enabled"))
        }
        sb.appendLine(runCmd("for f in /sys/block/sd*/queue/scheduler; do echo cfq > \$f 2>/dev/null || echo bfq > \$f 2>/dev/null; done", "io scheduler -> cfq/bfq"))
        return sb.toString()
    }

    fun applyBattery(root: Boolean): String {
        if (!root) return "modo bateria exige root."
        val gov = bestBatteryGovernor()
        val sb = StringBuilder()
        sb.appendLine(runCmd("for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $gov > \$c; done", "cpu governor -> $gov"))
        sb.appendLine(runCmd("for c in /sys/devices/system/cpu/cpu*/cpufreq; do max=\$(cat \$c/cpuinfo_max_freq 2>/dev/null); if [ -n \"\$max\" ]; then echo \$((max*7/10)) > \$c/scaling_max_freq 2>/dev/null; fi; done", "cpu max freq -> 70%"))
        return sb.toString()
    }

    fun restoreDefault(root: Boolean): String {
        if (!root) return "precisa root."
        val sb = StringBuilder()
        val gov = bestBalancedGovernor()
        sb.appendLine(runCmd("for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $gov > \$c; done", "cpu -> $gov"))
        sb.appendLine(runCmd("for c in /sys/devices/system/cpu/cpu*/cpufreq; do if [ -f \$c/cpuinfo_max_freq ]; then cat \$c/cpuinfo_max_freq > \$c/scaling_max_freq 2>/dev/null; fi; done", "cpu max freq -> padrao"))
        for (z in listThermalZones()) {
            runCmd("echo enabled > /sys/class/thermal/thermal_zone${z.index}/mode 2>/dev/null", "")
        }
        sb.appendLine(runCmd("echo 0 > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null", "adreno off"))
        sb.appendLine(runCmd("echo 0 > /sys/class/kgsl/kgsl-3d0/force_rail_on 2>/dev/null", ""))
        sb.appendLine(runCmd("echo 0 > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null", ""))
        sb.appendLine(runCmd("for f in /sys/block/sd*/queue/scheduler; do echo cfq > \$f 2>/dev/null; done", "io -> cfq"))
        return sb.toString()
    }

    fun isOverclockable(): Boolean {
        val avail = Shell.readSys("/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies")
        val max = Shell.readSys("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq").toLongOrNull() ?: 0
        if (avail == "N/A" || max == 0L) return false
        val availMax = avail.split(" ").filter { it.isNotBlank() }.mapNotNull { it.toLongOrNull() }.maxOrNull() ?: 0
        return availMax > max
    }

    fun hardwareSummary(): String = buildString {
        val rom = detectRom()
        val gpu = detectGpu()
        append("ROM: ${rom.name} ${rom.version}\n")
        append("Kernel: ${rom.kernel}\n")
        append("SoC: ${Build.HARDWARE}\n")
        append("Board: ${Build.BOARD}\n")
        append("Model: ${Build.MODEL}\n")
        append("Android: ${Build.VERSION.RELEASE}\n")
        append("GPU: ${gpu.second} (${gpu.first.name})\n")
        append("Cores: ${Runtime.getRuntime().availableProcessors()}\n")
        append("ABI: ${Build.SUPPORTED_ABIS.firstOrNull()}\n")
    }

    fun ramInfo(context: Context): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / (1024L * 1024L)
        val avail = mi.availMem / (1024L * 1024L)
        return "$avail MB livres / $total MB"
    }

    fun thermalStatus(): String {
        val zones = listThermalZones().filter { it.isCpu }
        return if (zones.isEmpty()) "N/A" else zones.joinToString(" | ") { "${it.type}: ${"%.1f".format(it.temp)}C" }
    }

    private fun runCmd(cmd: String, label: String): String {
        val r = Shell.exec(cmd, root = true)
        return when {
            r.code == 0 && label.isNotBlank() -> "OK $label"
            r.code == 0 -> ""
            else -> "FAIL $cmd"
        }
    }

    fun cleanRam(root: Boolean): String {
        val r = Shell.exec("sync; echo 3 > /proc/sys/vm/drop_caches", root)
        return if (r.code == 0) "RAM liberada." else "falhou (precisa root)"
    }

    fun killBackground(): String {
        val r = Shell.exec("am kill-all")
        return if (r.code == 0) "apps em background encerrados." else "falhou"
    }

    data class SysApp(val pkg: String, val name: String)
    private val CRITICAL = setOf(
        "android", "com.android.systemui", "com.android.settings",
        "com.google.android.gms", "com.google.android.gsf",
        "org.lineageos", "org.crdroid", "com.android.phone",
        "com.android.bluetooth", "com.android.nfc", "com.android.wifi"
    )

    fun listSystemApps(root: Boolean): List<SysApp> {
        if (!root) return emptyList()
        return Shell.exec("pm list packages -s", root = false).output.lines()
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:") }
            .filter { pkg -> CRITICAL.none { pkg.startsWith(it) } }
            .map { SysApp(it, it.substringAfterLast('.')) }
    }

    fun disableApp(pkg: String, root: Boolean): String {
        val r = Shell.exec("pm disable-user --user 0 $pkg", root)
        return if (r.code == 0) "desabilitado: $pkg" else "falhou: $pkg"
    }

    fun enableApp(pkg: String, root: Boolean): String {
        val r = Shell.exec("pm enable $pkg", root)
        return if (r.code == 0) "habilitado: $pkg" else "falhou: $pkg"
    }
}